import sqlite3
conn = sqlite3.connect('StudentDB.db')
c = conn.cursor()

# Display All Students and all their attributes
def allStudents():

    c.execute('SELECT * FROM Students')
    all_rows = c.fetchall()

    for r in all_rows:
        print(r)

# Create Students
def createStudent():
    studentID = input("What is the student's ID\n")
    firstName = input("What is the student's first name?\n")
    lastName = input("What is the student's last name?\n")
    GPA = input("What is the student's GPA?\n")
    major = input("What is the student's major?\n")
    facultyAdvisor = input("What is the student's faculty advisor?\n")

    params = (studentID, firstName, lastName, GPA, major, facultyAdvisor)

    c.execute("INSERT INTO Students VALUES (?,?,?,?,?,?)", params)
    print("Student successfully added")

# Update the major of a student
def updateMajor():
    studentID = input("What is the student's ID\n")
    major = input("What is the student's new major?\n")

    params = (major, studentID)

    c.execute("UPDATE Students SET Major = ? WHERE StudentID = ?", params)

    print("Student's major updated")

# Update the advisor of a student
def updateAdvisor():
    studentID = input("What is the student's ID\n")
    facultyAdvisor = input("What is the student's faculty advisor?\n")

    params = (facultyAdvisor, studentID)

    c.execute("UPDATE Students SET FalcultyAdvisor = ? WHERE StudentID = ?", params)

    print("Student's Advisor updated")

# Delete Students by studentID
def deleteStudent():
    studentID = input("What is the student's ID\n")

    c.execute("DELETE FROM Students WHERE StudentID = " + studentID)

    print("Student Deleted")

# Search/Display Students by Major
def searchMajor():

    major = input("What is the major?\n")

    c.execute("SELECT * FROM Students WHERE Major LIKE '" + major + "'")
    all_rows = c.fetchall()

    for r in all_rows:
        print(r)

def searchGPA():

    GPA = input("What is the GPA?\n")

    c.execute("SELECT * FROM Students WHERE GPA LIKE '" + GPA + "'")
    all_rows = c.fetchall()

    for r in all_rows:
        print(r)

def searchAdvisor():

    facultyAdvisor = input("What is the faculty advisor?\n")

    c.execute("SELECT * FROM Students WHERE FalcultyAdvisor LIKE '" + facultyAdvisor +"'")
    all_rows = c.fetchall()

    for r in all_rows:
        print(r)

# Main Method
option = ""

print("Welcome to the Student Database:")
print("1: Display All Students and all their attributes")
print("2: Create a Student")
print("3: Update Student's Major")
print("4: Update Student's Advisor")
print("5: Delete Student")
print("6: Search/Display students by Major")
print("7: Search/Display students by GPA")
print("8: Search/Display students by Advisor")
print("exit: To Close the Program")

while option != "exit":
    option = input("Please Select one of the following options:\n")

    if option == "1":
        allStudents()
    elif option == "2":
        createStudent()
    elif option == "3":
        updateMajor()
    elif option == "4":
        updateAdvisor()
    elif option == "5":
        deleteStudent()
    elif option == "6":
        searchMajor()
    elif option == "7":
        searchGPA()
    elif option == "8":
        searchAdvisor()
    elif option == "exit":
        break

conn.commit()
conn.close()