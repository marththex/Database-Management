package com.student;

public class Main {

    public static void main(String[] args) {

        DatabaseManager db = new DatabaseManager();
        Menu m = new Menu();

        int response = -2;
        int sid;

        while(DatabaseManager.serverIsOnline() && response != 0) {
            if(response == -2)
                m.displayMenu();

            response = -1;
            while (response < 0)
                response = m.promptResponse();

            switch(response){

                case(0): //Quit
                    System.out.println("Exiting.");
                    break;

                case(1): //Print all results

                    db.printResultSet(db.getAllRecords());
                    break;

                case(2): //Add a student
                    db.createStudent(m.promptStudentAttributes());
                    break;

                case(3): //Update student major
                    sid = m.promptStudentId();
                    if(db.studentExists(sid))
                        db.updateStudent(sid, m.promptStudentMajor(db.getStudent(sid)));
                    break;

                case(4): //Update student advisor
                    sid = m.promptStudentId();
                    if(db.studentExists(sid))
                        db.updateStudent(sid, m.promptStudentAdvisor(db.getStudent(sid)));
                    break;

                case(5): //Update student major and advisor
                    sid = m.promptStudentId();
                    if(db.studentExists(sid))
                        db.updateStudent(sid, m.promptStudentMajorAndAdvisor(db.getStudent(sid)));
                    break;

                case(6): //Delete student

                    sid = m.promptStudentId();
                    if(db.studentExists(sid))
                        db.deleteStudent(sid);
                    break;

                case(7): //Print major filtered results

                    db.printResultSet(db.getMajorFilteredRecords(m.promptMajor()));
                    break;

                case(8): //Print GPA filtered results
                    db.printResultSet(db.getGPAFilteredRecords(m.promptGPA()));
                    break;

                case(9): //Print advisor filtered results
                    db.printResultSet(db.getAdvisorFilteredRecords(m.promptAdvisor()));
                    break;
            }

        }

    }

}