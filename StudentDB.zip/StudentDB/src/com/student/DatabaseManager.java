package com.student;
import java.sql.*;

public class DatabaseManager {

    public static final String DRIVER_LOC = "com.mysql.jdbc.Driver";
    public static final String CONN_URL = "jdbc:mysql://localhost:3306/StudentDB";
    public static final String CONN_FLAGS = "?autoReconnect=true&useSSL=false";
    public static final String CONN_USER = "root";
    public static final String CONN_PASS = "password";

    public static Connection conn = null;

    public DatabaseManager() {
        getSQLConnection();
    }

    public static Connection getSQLConnection() {

        if (conn == null){

            try {
                Class.forName(DRIVER_LOC);
                conn = DriverManager.getConnection(CONN_URL + CONN_FLAGS, CONN_USER, CONN_PASS);
            }
            catch (Exception var2) {
                return null;
            }
        }

        return conn;
    }

    public static Boolean serverIsOnline(){
        if (getSQLConnection() != null) {
            return true;
        }
        else{
            System.out.println("SQL Server offline. Exiting application.");
            return false;
        }
    }

    public ResultSet getAllRecords(){
        try {
            System.out.println("Displaying all student records.");
            PreparedStatement p = conn.prepareStatement("SELECT * FROM Student");
            return p.executeQuery();
        }
        catch(Exception e){
            return null;
        }
    }

    public ResultSet getMajorFilteredRecords(String filter){
        try {
            System.out.println("Displaying all student records where major is " + filter + ".");
            PreparedStatement p = conn.prepareStatement("SELECT * FROM Student WHERE Major = ?");
            p.setString(1,filter);
            return p.executeQuery();
        }
        catch(Exception e){
            return null;
        }
    }

    public ResultSet getAdvisorFilteredRecords(String filter){
        try {
            System.out.println("Displaying all student records where advisor is " + filter + ".");
            PreparedStatement p = conn.prepareStatement("SELECT * FROM Student WHERE FacultyAdvisor = ?");
            p.setString(1,filter);
            return p.executeQuery();
        }
        catch(Exception e){
            return null;
        }
    }

    public ResultSet getGPAFilteredRecords(float gpa){
        try {
            System.out.println("Displaying all student records where gpa is " + gpa + ".");
            PreparedStatement p = conn.prepareStatement("SELECT * FROM Student WHERE GPA LIKE ?");
            p.setFloat(1,gpa);
            return p.executeQuery();
        }
        catch(Exception e){
            return null;
        }
    }

    public Boolean printResultSet(ResultSet r){
        String format = "%-10d %-25s %-25s %.2f %-10s %-25s\n";
        String format2 = "%-10s %-25s %-25s %-4s %-10s %-25s\n";


        try{
            if(!r.next()){
                System.out.println("No results.");
                return false;
            }

            System.out.printf(format2,"ID", "First Name", "Last Name", "GPA", "Major", "Faculty Advisor");
            while(r.next())
            {
                Integer id = r.getInt("StudentId");
                String fn = r.getString("FirstName");
                String ln = r.getString("LastName");
                Float GPA = r.getFloat("GPA");
                String maj = r.getString("Major");
                String adv = r.getString("FacultyAdvisor");

                System.out.printf(format,id,fn,ln,GPA,maj,adv);
            }
            return true;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }

    public Boolean createStudent(Student s){
        try{
            PreparedStatement p = conn.prepareStatement("INSERT INTO Student(FirstName, LastName, GPA, Major, FacultyAdvisor) VALUES (?,?,?,?,?);");
            p.setString(1, s.getFirstName());
            p.setString(2, s.getLastName());
            p.setFloat(3, s.getGPA());
            p.setString(4, s.getMajor());
            p.setString(5, s.getAdvisor());
            p.executeUpdate();
            System.out.println("Student added to database.");
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateStudent(int id, Student s){
        try{
            PreparedStatement p = conn.prepareStatement("UPDATE Student SET Major = ?, FacultyAdvisor = ? WHERE StudentId = ?");
            p.setString(1, s.getMajor());
            p.setString(2, s.getAdvisor());
            p.setInt(3, id);
            p.executeUpdate();
            System.out.println("Student updated.");
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }

    public boolean studentExists(int id){
        try{
            PreparedStatement p = conn.prepareStatement("SELECT * FROM Student WHERE StudentId = ?");
            p.setInt(1, id);
            ResultSet r = p.executeQuery();
            if (r.next())
                return true;
            else {
                System.out.println("That student does not exist. Returning to menu.");
                return false;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }

    public Student getStudent(int id){
        try{
            Student s = new Student();
            PreparedStatement p = conn.prepareStatement("SELECT * FROM Student WHERE StudentId = ?");
            p.setInt(1, id);
            ResultSet r = p.executeQuery();
            if (r.next()){
                s.setFirstName(r.getString("FirstName"));
                s.setLastName(r.getString("LastName"));
                s.setAdvisor(r.getString("FacultyAdvisor"));
                s.setGPA(r.getFloat("GPA"));
                s.setMajor(r.getString("Major"));
                return s;
            }

            return null;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public Boolean deleteStudent(int id){
        try{
            Student s = new Student();
            PreparedStatement p = conn.prepareStatement("DELETE FROM Student WHERE StudentId = ?");
            p.setInt(1, id);
            p.executeUpdate();
            System.out.println("Student deleted.");
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }

}